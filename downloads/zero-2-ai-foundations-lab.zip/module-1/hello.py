# Module 1, step 1: your first program.  Run: python3 module-1/hello.py
name = "Sam"                       # a variable: a labelled box holding a value
print(f"Hello, {name}!")           # an f-string: {name} is replaced by what's in the box
print("Let's build something real.")
