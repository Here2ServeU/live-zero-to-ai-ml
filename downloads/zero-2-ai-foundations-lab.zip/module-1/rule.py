# Module 1, step 2: a fraud rule YOU write.  Run: python3 module-1/rule.py
# Data in, decision out.

payments = [                                   # a list of dictionaries: one per payment
    {"id": 1, "amount": 42.50,  "hour": 14},
    {"id": 2, "amount": 1850.00, "hour": 3},
    {"id": 3, "amount": 1200.00, "hour": 15},
    {"id": 4, "amount": 7.99,   "hour": 2},
    {"id": 5, "amount": 2400.00, "hour": 4},
]

def is_fraud(payment):                         # a function: a named, reusable decision
    return payment["amount"] > 1000 and payment["hour"] < 6

flagged = 0
for p in payments:                             # a loop: do the same thing to every payment
    verdict = "FRAUD" if is_fraud(p) else "LEGIT"
    if verdict == "FRAUD":
        flagged += 1
    print(f"payment {p['id']}: ${p['amount']:>8.2f} at {p['hour']:>2}:00  ->  {verdict}")
print(f"{flagged} of {len(payments)} flagged")
