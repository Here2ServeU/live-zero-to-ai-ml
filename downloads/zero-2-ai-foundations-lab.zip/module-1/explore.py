# Module 1, step 3: meet real data, then test your rule on all of it.
# Run: python3 module-1/explore.py
import pandas as pd

df = pd.read_csv("data/transactions.csv")

# The four-question ritual: run it before you trust ANY dataset.
print("1. How big?      ", df.shape)                       # (rows, columns)
print("2. What's in it?\n", df.head())                     # the first 5 rows
print("3. What types? Anything missing?"); df.info()       # column types, empty cells
print("4. What ranges?\n", df.describe().round(1))         # min, max, mean per column

print("\nFraud vs legit:\n", df["is_fraud"].value_counts())

# Your Module 1 rule, applied to 5,000 payments at once
rule = (df["amount"] > 1000) & (df["hour"] < 6)
caught = (rule & (df["is_fraud"] == 1)).sum()
total_fraud = (df["is_fraud"] == 1).sum()
false_alarms = (rule & (df["is_fraud"] == 0)).sum()
print(f"\nYour rule caught {caught} of {total_fraud} frauds and raised {false_alarms} false alarms.")
