# Zero to AI Foundations

Transformed 2 Succeed (T2S) · Emmanuel Naweji

From zero code to a tested fraud-detection API in three modules. No experience needed.

| Module | Sticky idea | Lab |
|---|---|---|
| 1 · Talk to the Machine | **Data in, decision out.** | Terminal, five Python building blocks, a hand-written fraud rule tested on 5,000 payments |
| 2 · Teach a Machine the Rule | **Never grade on the study pile.** | Train a decision tree, catch overfitting, the accuracy trap, precision/recall and the threshold dial |
| 3 · Put Your Model to Work | **Save it, serve it, test it.** | Lab notebook, champion model, Flask API with validation, pytest |

## Setup
GitHub Codespaces (easiest), Windows (python.org installer, tick *Add Python to PATH*), or Mac. Python 3.10+.

```bash
git clone https://github.com/Here2ServeU/zero-2-ai-foundations
cd zero-2-ai-foundations
python3 -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python3 data/make_data.py
bash setup/doctor.sh
```
Windows: type `python` wherever the course says `python3`.

See **SCRIPTS.md** for what every script is and what it does.
