# Module 3: serve the model.  Run: python3 module-3/api.py      (then, in a second terminal, use curl)
import json
from pathlib import Path
import joblib
import pandas as pd
from flask import Flask, jsonify, request

HERE = Path(__file__).resolve().parent
FEATURES = ["amount", "hour", "new_device"]
model = joblib.load(HERE / "models" / "current.joblib")
card = json.loads((HERE / "models" / "current.json").read_text())
app = Flask(__name__)

def validate(data):
    errors = []
    for f in FEATURES:
        if f not in data:
            errors.append(f"missing field: {f}")
    if not errors:
        if not isinstance(data["amount"], (int, float)) or data["amount"] < 0:
            errors.append("amount must be a number >= 0")
        if data["hour"] not in range(24):
            errors.append("hour must be a whole number from 0 to 23")
        if data["new_device"] not in (0, 1):
            errors.append("new_device must be 0 or 1")
    return errors

@app.get("/health")
def health():
    return jsonify(status="ok", model_run=card["run"], threshold=card["threshold"])

@app.post("/predict")
def predict():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify(error="body must be JSON"), 400
    errors = validate(data)
    if errors:
        return jsonify(error="validation failed", details=errors), 422
    row = pd.DataFrame([[data[f] for f in FEATURES]], columns=FEATURES)
    score = float(model.predict_proba(row)[0, 1])
    label = "FRAUD" if score >= card["threshold"] else "LEGIT"
    return jsonify(label=label, fraud_score=round(score, 3), model_run=card["run"])

if __name__ == "__main__":
    app.run(port=5000)
