# Module 3: read the notebook, crown the best run.  Run: python3 module-3/best.py
# Our business rule: catch as much fraud as possible (recall), but at least 1 in 3 alarms must be real (precision >= 0.30).
import json, shutil
from pathlib import Path

runs = [json.loads(l) for l in open("module-3/runs.jsonl")]
print(f"{'run':>4} {'depth':>5} {'thresh':>6} {'recall':>7} {'precision':>9}")
for r in runs:
    print(f"{r['run']:>4} {r['max_depth']:>5} {r['threshold']:>6} {r['recall']:>7.0%} {r['precision']:>9.0%}")

eligible = [r for r in runs if r["precision"] >= 0.30]
if not eligible:
    raise SystemExit("no run meets precision >= 30% - try a higher threshold")
best = max(eligible, key=lambda r: (r["recall"], r["precision"]))
shutil.copy(best["model_file"], "module-3/models/current.joblib")
Path("module-3/models/current.json").write_text(json.dumps(best, indent=2) + "\n")
print(f"\nBest: run {best['run']} (recall {best['recall']:.0%}, precision {best['precision']:.0%}) -> models/current.joblib")
