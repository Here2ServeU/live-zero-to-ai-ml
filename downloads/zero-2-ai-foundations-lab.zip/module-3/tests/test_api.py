# Module 3: let the computer check the API for you.  Run: python3 -m pytest module-3/tests -q
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from api import app

client = app.test_client()

def test_health():
    r = client.get("/health")
    assert r.status_code == 200 and r.get_json()["status"] == "ok"

def test_big_night_payment_is_fraud():
    r = client.post("/predict", json={"amount": 2500, "hour": 3, "new_device": 1})
    assert r.status_code == 200 and r.get_json()["label"] == "FRAUD"

def test_small_daytime_payment_is_legit():
    r = client.post("/predict", json={"amount": 25, "hour": 14, "new_device": 0})
    assert r.get_json()["label"] == "LEGIT"

def test_bad_hour_is_refused():
    r = client.post("/predict", json={"amount": 25, "hour": 99, "new_device": 0})
    assert r.status_code == 422

def test_missing_field_is_listed():
    r = client.post("/predict", json={"hour": 3, "new_device": 0})
    assert "missing field: amount" in r.get_json()["details"]
