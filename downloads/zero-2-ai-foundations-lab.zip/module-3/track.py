# Module 3: train, then write it in the lab notebook.  Run: python3 module-3/track.py --max_depth 4 --threshold 0.2
import argparse, json, time
from pathlib import Path
import joblib
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score

ap = argparse.ArgumentParser()
ap.add_argument("--max_depth", type=int, default=4)
ap.add_argument("--threshold", type=float, default=0.5)
args = ap.parse_args()

FEATURES = ["amount", "hour", "new_device"]
df = pd.read_csv("data/transactions.csv")
X_train, X_test, y_train, y_test = train_test_split(df[FEATURES], df["is_fraud"], test_size=0.2, random_state=42, stratify=df["is_fraud"])
model = DecisionTreeClassifier(max_depth=args.max_depth, random_state=42).fit(X_train, y_train)
pred = (model.predict_proba(X_test)[:, 1] >= args.threshold).astype(int)

runs = Path("module-3/runs.jsonl")
run_id = sum(1 for _ in open(runs)) + 1 if runs.exists() else 1
Path("module-3/models").mkdir(exist_ok=True)
model_file = f"module-3/models/run-{run_id:03d}.joblib"
joblib.dump(model, model_file)                              # a trained model is just a file

entry = {"run": run_id, "time": time.strftime("%Y-%m-%d %H:%M:%S"),
         "max_depth": args.max_depth, "threshold": args.threshold,
         "recall": round(recall_score(y_test, pred), 3), "precision": round(precision_score(y_test, pred, zero_division=0), 3),
         "accuracy": round(accuracy_score(y_test, pred), 3), "model_file": model_file}
with open(runs, "a") as f:
    f.write(json.dumps(entry) + "\n")                       # one line per run: the lab notebook
print(f"run {run_id}: depth={args.max_depth} threshold={args.threshold}  recall {entry['recall']:.0%}  precision {entry['precision']:.0%}  -> {model_file}")
