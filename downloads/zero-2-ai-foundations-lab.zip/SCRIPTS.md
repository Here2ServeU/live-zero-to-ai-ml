# Lab scripts: what each one is and what it does

Zero to AI Foundations · T2S · Emmanuel Naweji

Every script is short Python you can open and read in VS Code. Run them all from the repo folder, with your `(.venv)` active.

| Script | What it is | What it does | Module |
|---|---|---|---|
| `setup/doctor.sh` | The health check | Checks Python, Git, the five packages and the dataset | all |
| `data/make_data.py` | The dataset maker | Writes `data/transactions.csv`: 5,000 pretend payments, 137 fraud | all |
| `module-1/hello.py` | Your first program | A variable and two print lines | 1 |
| `module-1/rule.py` | Your hand-written rule | Five payments, one `is_fraud` function, a verdict for each | 1 |
| `module-1/explore.py` | The data explorer | The four-question ritual, then your rule on all 5,000 payments | 1 |
| `module-2/train.py` | The trainer | Split, choose, train, predict, score; study vs quiz accuracy | 2 |
| `module-2/judge.py` | The honest judge | The "always LEGIT" trap, the four boxes, precision, recall, threshold | 2 |
| `module-3/track.py` | The lab notebook | Trains, saves `models/run-NNN.joblib`, appends a line to `runs.jsonl` | 3 |
| `module-3/best.py` | The judge's rule | Picks the highest recall with precision ≥ 30% → `models/current.joblib` | 3 |
| `module-3/api.py` | The service | Flask API: `GET /health`, `POST /predict`, validation (400 / 422) | 3 |
| `module-3/tests/test_api.py` | The robot checker | Five pytest checks on the API | 3 |

---

## setup/doctor.sh — the health check
**Run:** `bash setup/doctor.sh`
One `[ OK ]` or `[WARN]` line per check: Python, Git, packages pandas / sklearn / joblib / flask / pytest, and the dataset. Each WARN says how to fix it.

## data/make_data.py — the dataset maker
**Run:** `python3 data/make_data.py` → `wrote 5000 payments to data/transactions.csv (137 fraud)`
Fixed seed (42), so everyone gets the same file. Columns: `id, amount, hour, new_device, is_fraud`. Amounts are mostly small with a few large ones. Each payment gets a *chance* of fraud: big amounts at night raise it, a new device adds a little; then the dice are rolled. So the data is messy like real life: some risky payments are innocent, some fraud fits no rule.

## module-1/hello.py — your first program
**Run:** `python3 module-1/hello.py` → `Hello, Sam!`
A variable (`name = "Sam"`) and an f-string that looks inside it. Change the name, save, run again.

## module-1/rule.py — your hand-written rule
**Run:** `python3 module-1/rule.py` → `2 of 5 flagged`
Uses all five building blocks: a list of dictionaries (five payments), a function `is_fraud` (`amount > 1000 and hour < 6`), a loop, and a variable holding FRAUD or LEGIT.

## module-1/explore.py — the data explorer
**Run:** `python3 module-1/explore.py`
Loads the CSV with pandas and runs the ritual: `df.shape`, `df.head()`, `df.info()`, `df.describe()`, plus the fraud count. Then it applies your rule to every row at once (pandas uses `&` instead of `and`) and counts caught frauds and false alarms:
`Your rule caught 61 of 137 frauds and raised 59 false alarms.`

## module-2/train.py — the trainer
**Run:** `python3 module-2/train.py` or `python3 module-2/train.py --max_depth 3`
The five-step recipe. **Split** 80/20 with `stratify` so both piles get fraud. **Choose** a `DecisionTreeClassifier`. **Train** with `fit` on the study pile only. **Predict + score** on both piles.

| Setting | Tree | Study | Quiz |
|---|---|---|---|
| no limit | 20 levels, 160 leaves | 100.0% | 95.8% |
| `--max_depth 3` | 3 levels, 8 leaves | 97.7% | 98.0% |

At depth ≤ 3 it prints the flowchart it wrote. The FRAUD branch: `amount > 1412` and `hour <= 6`, close to your Module 1 rule.

## module-2/judge.py — the honest judge
**Run:** `python3 module-2/judge.py [--threshold 0.5]`
First the trap: a "model" that always says LEGIT scores 97.3% accuracy and catches 0 frauds. Then a depth-4 tree gives every quiz payment a fraud score (`predict_proba`), and the threshold turns scores into FRAUD/LEGIT. Prints the confusion matrix (the four boxes), accuracy, precision and recall. Quiz pile: 1,000 payments, 27 fraud.

| Threshold | Caught | False alarms | Precision | Recall |
|---|---|---|---|---|
| 0.5 | 8 | 6 | 57.1% | 29.6% |
| 0.2 | 18 | 35 | 34.0% | 66.7% |
| 0.1 | 21 | 66 | 24.1% | 77.8% |

## module-3/track.py — the lab notebook
**Run:** `python3 module-3/track.py --max_depth 4 --threshold 0.2`
Trains with your settings, scores on the quiz pile, saves the model with `joblib.dump` to `module-3/models/run-NNN.joblib` (numbered, never overwritten), and appends one JSON line to `module-3/runs.jsonl`: run number, time, settings, recall, precision, accuracy, model file.

## module-3/best.py — the judge's rule
**Run:** `python3 module-3/best.py`
Prints the notebook as a table. Keeps runs with precision ≥ 0.30, picks the highest recall (precision breaks ties), copies its model to `module-3/models/current.joblib` and writes `module-3/models/current.json` (the model card). With the four course runs (depth 4 at 0.5 / 0.2 / 0.1, depth 8 at 0.2), run 2 wins: recall 67%, precision 34%.

## module-3/api.py — the service
**Run:** `python3 module-3/api.py` (stays running on port 5000; stop with Ctrl-C)
Loads `current.joblib` and the threshold from `current.json` once at start.
- `GET /health` → `{"model_run": 2, "status": "ok", "threshold": 0.2}`
- `POST /predict` with JSON `{"amount": 2500, "hour": 3, "new_device": 1}` → `{"fraud_score": 1.0, "label": "FRAUD", "model_run": 2}`
- Not JSON → **400**. Missing field, negative amount, hour outside 0–23, or new_device not 0/1 → **422** with a list of every problem. Bad input never reaches the model.

```bash
curl -X POST localhost:5000/predict -H "Content-Type: application/json" \
     -d '{"amount": 2500, "hour": 3, "new_device": 1}'
```
Windows PowerShell: use `curl.exe`, or Git Bash / Codespaces.

## module-3/tests/test_api.py — the robot checker
**Run:** `python3 -m pytest module-3/tests -q` → `5 passed`
Uses Flask's `test_client` (no server needed). Five checks: health is OK; a big night-time payment is FRAUD; a small daytime payment is LEGIT; hour 99 gets 422; a missing amount is listed by name. Needs `best.py` to have run first.

---

**In real life:** `runs.jsonl` → MLflow or a model registry · `best.py` → a CI/CD promotion gate · `api.py` → FastAPI/Flask in a container behind a load balancer · `pytest` → runs in CI on every change. The Full Course builds all of these.
