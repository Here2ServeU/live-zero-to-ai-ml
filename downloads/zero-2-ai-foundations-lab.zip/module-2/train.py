# Module 2: let the machine learn the rule.  Run: python3 module-2/train.py [--max_depth 3]
# Split, choose, train, predict, score.
import argparse
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import accuracy_score

ap = argparse.ArgumentParser()
ap.add_argument("--max_depth", type=int, default=None, help="how many questions deep the tree may go (default: no limit)")
args = ap.parse_args()

df = pd.read_csv("data/transactions.csv")
FEATURES = ["amount", "hour", "new_device"]
X, y = df[FEATURES], df["is_fraud"]                    # X = the clues, y = the answers

# 1 SPLIT: 80% study pile, 20% quiz pile the model never sees. stratify keeps fraud in both.
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# 2 CHOOSE: an empty decision tree. Nothing learned yet.
model = DecisionTreeClassifier(max_depth=args.max_depth, random_state=42)

# 3 TRAIN: study the training pile (clues AND answers).
model.fit(X_train, y_train)

# 4 PREDICT + 5 SCORE, on both piles. The gap is the diagnosis.
train_acc = accuracy_score(y_train, model.predict(X_train))
test_acc = accuracy_score(y_test, model.predict(X_test))
print(f"max_depth={args.max_depth}  ->  tree has {model.get_depth()} levels, {model.get_n_leaves()} leaves")
print(f"train accuracy {train_acc:.1%}   test accuracy {test_acc:.1%}   gap {train_acc - test_acc:+.1%}")

if model.get_depth() <= 3:
    print("\nThe flowchart it wrote for itself:")
    print(export_text(model, feature_names=FEATURES, decimals=0))
