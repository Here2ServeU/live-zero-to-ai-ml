# Module 2: judge the model honestly.  Run: python3 module-2/judge.py [--threshold 0.5]
import argparse
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score

ap = argparse.ArgumentParser()
ap.add_argument("--threshold", type=float, default=0.5, help="flag FRAUD when the model's fraud score is at least this")
args = ap.parse_args()

df = pd.read_csv("data/transactions.csv")
FEATURES = ["amount", "hour", "new_device"]
X_train, X_test, y_train, y_test = train_test_split(df[FEATURES], df["is_fraud"], test_size=0.2, random_state=42, stratify=df["is_fraud"])

# The trap first: a "model" that ignores its input and always says LEGIT.
always_legit = [0] * len(y_test)
print(f"'Always LEGIT' accuracy: {accuracy_score(y_test, always_legit):.1%}  ...and it catches {sum(always_legit)} frauds.\n")

model = DecisionTreeClassifier(max_depth=4, random_state=42).fit(X_train, y_train)
scores = model.predict_proba(X_test)[:, 1]              # fraud score per payment, 0.0 to 1.0
pred = (scores >= args.threshold).astype(int)           # the dial: where do we draw the line?

tn, fp, fn, tp = confusion_matrix(y_test, pred).ravel()
print(f"Threshold {args.threshold}   (test pile: {len(y_test)} payments, {int(y_test.sum())} fraud)")
print(f"  caught fraud (TP)    {tp:>4}      missed fraud (FN)  {fn:>4}")
print(f"  false alarms (FP)    {fp:>4}      correctly legit    {tn:>4}")
print(f"accuracy  {accuracy_score(y_test, pred):.1%}")
print(f"precision {precision_score(y_test, pred, zero_division=0):.1%}   when it shouts FRAUD, how often is it right?")
print(f"recall    {recall_score(y_test, pred, zero_division=0):.1%}   of all real fraud, how much did it catch?")
