#!/usr/bin/env python3
"""Make the course dataset: 5,000 card payments, about 2% fraud.
Run once:  python3 data/make_data.py   ->  data/transactions.csv
The hidden pattern: large amounts at night (and new devices) are riskier. Risky is not certain."""
import csv, random
from pathlib import Path

rng = random.Random(42)                     # fixed seed: everyone gets the same file
rows = []
for i in range(1, 5001):
    amount = round(rng.expovariate(1 / 400), 2)        # most payments small, a few large
    hour = rng.randrange(24)
    new_device = 1 if rng.random() < 0.15 else 0
    p = 0.0                                             # chance this payment is fraud
    if hour < 6:
        p += min(max((amount - 500) / 1500, 0), 0.85)   # big AND at night: risky
    if new_device:
        p += 0.03 + min(max((amount - 800) / 3000, 0), 0.3)   # a new phone or laptop adds risk
    fraud = 1 if rng.random() < p else 0                # real life: risky isn't certain
    rows.append({"id": i, "amount": amount, "hour": hour, "new_device": new_device, "is_fraud": fraud})

out = Path(__file__).resolve().parent / "transactions.csv"
with open(out, "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(f"wrote {len(rows)} payments to data/transactions.csv ({sum(r['is_fraud'] for r in rows)} fraud)")
