#!/usr/bin/env bash
# Zero to AI Foundations - check your machine.  Run: bash setup/doctor.sh
ok()   { printf "  [ OK ]  %s\n" "$1"; }
warn() { printf "  [WARN]  %s\n" "$1"; }
echo "Zero to AI Foundations - doctor"; echo "-------------------------------"
PY=python3; command -v python3 >/dev/null || PY=python
if command -v $PY >/dev/null; then ok "$($PY --version)"; else warn "Python missing: install from python.org/downloads"; fi
command -v git >/dev/null && ok "$(git --version)" || warn "Git missing: install from git-scm.com/downloads"
for p in pandas sklearn joblib flask pytest; do
  if $PY -c "import $p" 2>/dev/null; then ok "package $p"; else warn "package $p missing: pip install -r requirements.txt"; fi
done
[ -f data/transactions.csv ] && ok "dataset ready" || warn "dataset missing: python3 data/make_data.py"
echo "-------------------------------"
